window.isCommandFrame = true;
